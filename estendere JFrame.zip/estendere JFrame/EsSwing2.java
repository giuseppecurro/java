public class EsSwing2 {
    public static void main(String[] v){
        MyFrame f = new MyFrame("Esempio 2");
        f.setVisible(true);
    }
}