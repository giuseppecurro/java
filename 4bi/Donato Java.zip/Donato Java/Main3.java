import java.util.Vector;
import java.util.Scanner;
public class Main3
{
    public static void main (String args[]){
        Coda coda = new Coda();
        Pila pilacom = new Pila();
        Persona P;
        Scanner sc = new Scanner(System.in);
      
}
}